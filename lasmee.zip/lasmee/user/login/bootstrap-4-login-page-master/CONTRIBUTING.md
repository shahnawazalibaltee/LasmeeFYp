# Contribution
Contribution are always welcome and recommended! Here is how:
- Fork the repository (here is the guide).
- Clone to your machine git clone https://github.com/YOUR_USERNAME/my-login.git
- Make your changes
- Create a pull request

Enjoy! :)
