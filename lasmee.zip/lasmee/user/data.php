<!-- <?php

// Set the database credentials
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "lasmee";

// Create a connection to the database
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Retrieve the form data and sanitize it
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);

    // Prepare the SQL query and bind the parameters
    $sql = "INSERT INTO login (email, password, status, type) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'ssss', $email, $password, $status, $type);

    // Execute the query and handle errors
    if (mysqli_stmt_execute($stmt)) {
        // Store user type and ID in session
        session_start();
        $_SESSION['user_type'] = $type;
        $_SESSION['user_id'] = mysqli_insert_id($conn);
        // Redirect the user based on the user type
        if ($type == "lasmee") {
            header("Location: ../skillful/index.html");
        }
        elseif ($type == "hirer") {
            header("Location: ../hirer/index.html");
        }
    }
    else {
        echo "Error: " . mysqli_error($conn);
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}

// Close the database connection
mysqli_close($conn);
?>
