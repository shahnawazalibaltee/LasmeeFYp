<?php
session_start();
// Set the database credentials
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "lasmee";

// Create a connection to the database
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];
    $picture = $_POST['picture'];
    $cnic = $_POST['cnic'];
    $country = $_POST['country'];
    $region = $_POST['region'];
    $city = $_POST['city'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $id = $_SESSION['user_id']; // Get the user id from the session
    $type=$_SESSION['user_type'];
    // Prepare the SQL query
    $sql="INSERT INTO hirer (id, name, mobile, gender, picture, cnic, country, region, city, address, email) VALUES ('$id','$name', '$mobile', '$gender', '$picture', '$cnic', '$country', '$region', '$city', '$address', '$email')";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        echo "Data inserted successfully";
        header("Location: index.html");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
// Close the database connection
mysqli_close($conn);
?>
